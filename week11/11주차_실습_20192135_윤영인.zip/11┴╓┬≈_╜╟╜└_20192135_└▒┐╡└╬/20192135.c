#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

char **maze;
int row, col, N, M;
int *set;

int findParent(int x) {
    if (set[x] == x)
        return x;
    return set[x] = findParent(set[x]);
}

void unionParent(int x, int y) {
    x = findParent(x);
    y = findParent(y);

    if(x < y)
        set[y] = x;
    else set[x] = y;
}

void initParent() {
    set = (int *)malloc(sizeof(int) * N * M);
    for (int i = 0; i < N * M; i++) {
        set[i] = i;
    }
}

void InitMaze() {
    for (int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++) {
            if (i % 2 == 0) {
                if (j % 2 == 0)
                    maze[i][j] = '+';
                else
                    maze[i][j] = '-'; // 가로 벽
            } else {
                if (j % 2 == 0)
                    maze[i][j] = '|'; // 세로 벽
                else
                    maze[i][j] = ' ';
            }
        }
    }
}


void MakeMaze() {
    initParent();
    for (int i = 1; i < row; i += 2) {
        for (int j = 1; j < col; j += 2) {
            int curNum = (i / 2) * (col / 2) + (j / 2);
            int curParent = findParent(curNum);

            // 현재 위치에서 오른쪽에 벽이 있을 때
            if (j + 2 < col) {
                 // 현재 행이 미로 전체 틀의 행을 벗어났거나, 벗어나지는 않았지만 랜덤 조건이 성립하면
                if (i + 2 >= row || (i + 2 < row && rand() % 2 == 0)) {
                    // 오른쪽 벽 뚫기
                    int rightParent = findParent(curNum + 1);
                    if (curParent != rightParent) {
                        maze[i][j + 1] = ' '; 
                        unionParent(curParent, rightParent); // 부모 합치기
                    }
                }
            }
            
            if (i + 2 < row) {
                // 현재 열이 미로 전체 틀의 열을 벗어났거나, 벗어나지는 않았지만 랜덤 조건이 성립하면
                if(j + 2 >= col || (j + 2 < col && rand() % 2 == 0)) {
                    // 아래쪽 벽 뚫기
                    int downNum = curNum + (col / 2);
                    int downParent = findParent(downNum);
                    if (curParent != downParent) {
                        maze[i + 1][j] = ' '; 
                        unionParent(curParent, downParent); // 부모 합치기
                    }
                }
            }
        }
    }

    free(set);
}

void FreeMaze() {
    for (int i = 0; i < row; i++) {
        free(maze[i]);
    }
    free(maze);
}

void PrintMaze() {
    for (int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++) {
            printf("%c", maze[i][j]);
        }
        printf("\n");
    }
}

void DrawMaze() {
    FILE *fp = fopen("maze_20192135.maz", "w");
    if(!fp) {
        printf("file open error!\n");
        return;
    }

    for(int i = 0; i < row; i++) {
        for(int j = 0; j < col; j++) {
            fprintf(fp, "%c", maze[i][j]);
        }
        fprintf(fp, "\n");
    }
    fclose(fp);

}
int main() {
    scanf("%d %d", &N, &M);

    col = 2 * N + 1;
    row = 2 * M + 1;

    maze = (char **)malloc(sizeof(char *) * row);
    for (int i = 0; i < row; i++) {
        maze[i] = (char *)malloc(sizeof(char) * col);
    }

    srand(time(NULL));
    InitMaze();
    MakeMaze();
    PrintMaze();
    DrawMaze();
    FreeMaze();

    return 0;
}
