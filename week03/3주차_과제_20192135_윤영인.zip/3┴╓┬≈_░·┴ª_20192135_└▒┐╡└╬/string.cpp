#include "String.h"
#include <iostream>
#include <cstdlib>
#include <string.h>

using namespace std;
Str::Str(int leng)
{
	// leng을 확인하여 음수이면 에러메시지를 출력하고 종료
	if (leng <= 0)
	{
		cout << "size is too small!\n";
		return;
	}
	else
	{
		// 양수이면 leng 만큼 char 형 배열 str을 할당
		str = new char[leng];
  		//len에 leng 값을 넣어줌
  		len = leng;
 	}
}

Str::Str(char *neyong)
{
	if(strlen(neyong) <= 0)
	{	
		// neyong이 비어있이면 에러메시지를 출력하고 종료
		cout << "Neyong is empty!\n";
		return;
	}
	else
	{
		len = strlen(neyong); // len에 neyong의 길이를 넣어줌
		str = new char[len]; // len만큼 char형 배열 str을 할당
		strcpy(str, neyong); // str에 neyong 문자열을 넣어줌
	}
}

Str::~Str()
{
	// 소멸자, 할당된 str 메모리를 해제
	delete [] str;
}

int Str::length(void)
{
	//string의 길이를 리턴
	return len;
}

char* Str::contents(void)
{
	//string의 내용을 리턴
	return str;
}

int Str::compare(class Str& a)
{
	// Class a의 contents()내용과 strcmp, 같으면 0 리턴
	return strcmp(str, a.contents());
}

int Str::compare(char *a)
{
	//문자열 a와 str을 비교, 같으면 0 리턴
	return strcmp(str, a);
}

void Str::operator=(char *a)
{
	//string의 값을 대입
	if(strlen(a) <= 0) // a가 비어있으면
	{
		cout << "empty!\n"; // 에러 메시지를 출력하고
		len = 0; // str의 len에 0 을 대입
		delete [] str; // 할당된 str을 할당 해제
	}
	else {
		delete [] str; // 이전에 할당된 str을 할당해제
		len = strlen(a); // len에 a의 길이를 넣어줌
		str = new char[len]; // len 만큼 char형 배열인 str을 할당
		strcpy(str, a); // str에 a의 내용을 copy
	}
}

void Str::operator=(class Str& a)
{	//Str의 내용을 대입
	if (strlen(a.contents()) <= 0) // a의 content가 비어있으면
	{	
		cout << "contents empty!\n"; // 에러 메시지를 출력하고
		len = 0; // len에 0을 대입
		delete [] str; // 할당된 str을 할당 해제
	}
	else {
		//Str의 내용을 대입
		delete [] str; // 이전에 할당된 str을 할당해제
		len = strlen(a.contents()); // len에 a의 contents의 길이를 넣어줌
		str = new char[len]; // len만큼 char형 배열인 str 할당
		strcpy(str, a.contents()); // str에 a의 contents()를 copy
	}
}
