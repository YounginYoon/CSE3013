#include "String.h"
#include <iostream>

using namespace std;
int main()
{
	Str a((char*)"I'm a girl");
	cout << a.contents() << endl;
	a = (char*)"I'm a boy\n";
	cout << a.contents();
	cout << a.compare((char*)"I'm a a") << endl;
	
	Str mytest((char*)"Youngin Yoon's Homework!");
	cout << mytest.contents() << endl;
	cout << "mytest length: " << mytest.length() << endl;
	cout << "compare a and mytest: " << mytest.compare(a) << endl;
	cout << "compare mytest and \'Youngin\': " << mytest.compare((char*)"Youngin") << endl;
	cout << "compare mytest and \'Youngin Y\': " << mytest.compare((char*)"Youngin Y") << endl;

	mytest = a;
	cout << mytest.contents();
	cout << mytest.compare(a) << endl;
	
	Str c(5);
	cout << c.length() << endl;
	Str d(-1);
	return 0;
}
