#include "Header.h"

/* StarWars 함수에서 인자로 받아온 num 배열 안에 들어있는 숫자를 출력하는 함수
*/
void print_answer(int *num) {
	// 0 ~ 9가 몇 개가 들어있는지 들어있는 배열인 num을 출력한다.
        for(int i = 0; i < 10; i++) {
                printf("%d ", num[i]);
        }
	printf("\n");
}
