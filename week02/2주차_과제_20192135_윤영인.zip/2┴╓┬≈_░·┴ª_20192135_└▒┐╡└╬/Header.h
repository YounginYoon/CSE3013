#include <stdio.h>
#include <string.h> // StarWars 함수에서 num 배열을 초기화하는 memset 함수가 들어있는 헤더

void StarWars(int page); // StarWars 함수를 정의
void print_answer(int *num); // print_answer 함수를 정의

