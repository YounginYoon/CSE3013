#include "Header.h"

int main(void) {
	int N, page; // N: 테스트 케이스 개수, page: 페이지 수
        
        scanf("%d", &N);
        for(int i = 0; i < N; i++) {
                scanf("%d", &page); // 페이지의 수를 입력 받음
		if(page < 1 || page > 1000000000) { 
		// 페이지 수가 1~1,000,000,000의 범위를 넘어가면 에러 메시지를 내고 continue
			printf("wrong input\n");
			continue;
		}
                StarWars(page); // page 에 구성된 숫자를 세는 함수
        }
}
