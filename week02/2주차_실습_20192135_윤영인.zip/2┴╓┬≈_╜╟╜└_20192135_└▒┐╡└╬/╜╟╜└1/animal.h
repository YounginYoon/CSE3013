#include <stdio.h>

void dog();
void blackcow();
void turtle();
