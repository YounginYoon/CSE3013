#include "animal.h"

int main(void) {
	printf("make success!\n");
	dog();
	blackcow();
	turtle();
	
	return 0;
}
