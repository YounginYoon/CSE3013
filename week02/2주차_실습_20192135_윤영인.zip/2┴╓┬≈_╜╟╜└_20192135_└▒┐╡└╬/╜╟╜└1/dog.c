#include "animal.h"

void dog() {
	printf("dog\n");
}
