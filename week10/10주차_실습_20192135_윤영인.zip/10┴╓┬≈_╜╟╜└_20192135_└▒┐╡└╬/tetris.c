﻿#include "tetris.h"

static struct sigaction act, oact;

int main(){
	int exit=0;

	initscr();
	noecho();
	keypad(stdscr, TRUE);	

	srand((unsigned int)time(NULL));
	createRankList();
	
	while(!exit){
		clear();
		switch(menu())
		{
		case MENU_PLAY: 
			play(); 
			break;
		case MENU_RANK: 
			rank(); 
			break;
		case MENU_EXIT: 
			exit=1; 
			break;
		default: 
			break;
		}
	}


	endwin();
	system("clear");
	return 0;
}

RecNode* InitRecTree() {
	recommendX = 0;
	recommendY = 0;
	recommendR = 0;
	RecNode* newRoot = (RecNode*) malloc(sizeof(RecNode));
	newRoot->accumulatedScore = 0;
	newRoot->level = 1;
	memcpy(newRoot->recField, field, sizeof(field));

	return newRoot;
}

void InitTetris(){
	int i,j;

	for(j=0;j<HEIGHT;j++)
		for(i=0;i<WIDTH;i++)
			field[j][i]=0;

	/* next Block update */
	for(int i = 0; i < BLOCK_NUM; i++)
		nextBlock[i] = rand() % 7;

	blockRotate=0;
	blockY=-1;
	blockX=WIDTH/2-2;
	score=0;	
	gameOver=0;
	timed_out=0;

	/* recommend */
	recRoot = InitRecTree();
	recommend(recRoot);

	DrawOutline();
	DrawField();
	DrawBlockWithFeatures(blockY, blockX, nextBlock[0], blockRotate);
	//DrawBlock(blockY,blockX,nextBlock[0],blockRotate,' ');
	DrawNextBlock(nextBlock);
	PrintScore(score);
}

void DrawOutline(){	
	int i,j;
	/* 블럭이 떨어지는 공간의 태두리를 그린다.*/
	DrawBox(0,0,HEIGHT,WIDTH);

	/* 1번째 next block을 보여주는 공간의 태두리를 그린다.*/
	move(2,WIDTH+10);
	printw("NEXT BLOCK");
	DrawBox(3,WIDTH+10,4,8);

	/* 2번째 next block을 보여주는 공간의 태두리를 그린다.*/
	DrawBox(9,WIDTH+10,4,8);

	/* score를 보여주는 공간의 태두리를 그린다.*/
	move(15,WIDTH+10);
	printw("SCORE");
	DrawBox(16,WIDTH+10,1,8);
}

int GetCommand(){
	int command;
	command = wgetch(stdscr);
	switch(command){
	case KEY_UP:
		break;
	case KEY_DOWN:
		break;
	case KEY_LEFT:
		break;
	case KEY_RIGHT:
		break;
	case ' ':	/* space key*/
		/*fall block*/
		break;
	case 'q':
	case 'Q':
		command = QUIT;
		break;
	default:
		command = NOTHING;
		break;
	}
	return command;
}

int ProcessCommand(int command){
	int ret=1;
	int drawFlag=0;
	switch(command){
	case QUIT:
		ret = QUIT;
		break;
	case KEY_UP:
		if((drawFlag = CheckToMove(field,nextBlock[0],(blockRotate+1)%4,blockY,blockX)))
			blockRotate=(blockRotate+1)%4;
		break;
	case KEY_DOWN:
		if((drawFlag = CheckToMove(field,nextBlock[0],blockRotate,blockY+1,blockX)))
			blockY++;
		break;
	case KEY_RIGHT:
		if((drawFlag = CheckToMove(field,nextBlock[0],blockRotate,blockY,blockX+1)))
			blockX++;
		break;
	case KEY_LEFT:
		if((drawFlag = CheckToMove(field,nextBlock[0],blockRotate,blockY,blockX-1)))
			blockX--;
		break;
	default:
		break;
	}
	if(drawFlag) DrawChange(field,command,nextBlock[0],blockRotate,blockY,blockX);
	return ret;	
}

void DrawField(){
	int i,j;
	for(j=0;j<HEIGHT;j++){
		move(j+1,1);
		for(i=0;i<WIDTH;i++){
			if(field[j][i]==1){
				attron(A_REVERSE);
				printw(" ");
				attroff(A_REVERSE);
			}
			else printw(".");
		}
	}
}


void PrintScore(int score){
	move(17,WIDTH+11);
	printw("%8d",score);
}

void DrawNextBlock(int *nextBlock){
	int i, j;
	for( i = 0; i < 4; i++ ){
		move(4+i,WIDTH+13);
		for( j = 0; j < 4; j++ ){
			if( block[nextBlock[1]][0][i][j] == 1 ){
				attron(A_REVERSE);
				printw(" ");
				attroff(A_REVERSE);
			}
			else printw(" ");
		}
	}

	// 2번째 next 블록 그림
	for( i = 0; i < 4; i++ ){
		move(10+i,WIDTH+13);
		for( j = 0; j < 4; j++ ){
			if( block[nextBlock[2]][0][i][j] == 1 ){
				attron(A_REVERSE);
				printw(" ");
				attroff(A_REVERSE);
			}
			else printw(" ");
		}
	}
}

void DrawBlock(int y, int x, int blockID,int blockRotate,char tile){
	int i,j;
	for(i=0;i<4;i++)
		for(j=0;j<4;j++){
			if(block[blockID][blockRotate][i][j]==1 && i+y>=0){
				move(i+y+1,j+x+1);
				attron(A_REVERSE);
				printw("%c",tile);
				attroff(A_REVERSE);
			}
		}

	move(HEIGHT,WIDTH+10);
}

void DrawBox(int y,int x, int height, int width){
	int i,j;
	move(y,x);
	addch(ACS_ULCORNER);
	for(i=0;i<width;i++)
		addch(ACS_HLINE);
	addch(ACS_URCORNER);
	for(j=0;j<height;j++){
		move(y+j+1,x);
		addch(ACS_VLINE);
		move(y+j+1,x+width+1);
		addch(ACS_VLINE);
	}
	move(y+j+1,x);
	addch(ACS_LLCORNER);
	for(i=0;i<width;i++)
		addch(ACS_HLINE);
	addch(ACS_LRCORNER);
}

void play(){
	int command;
	clear();
	act.sa_handler = BlockDown;
	sigaction(SIGALRM,&act,&oact);
	InitTetris();
	do{
		if(timed_out==0){
			alarm(1);
			timed_out=1;
		}

		command = GetCommand();
		if(ProcessCommand(command)==QUIT){
			alarm(0);
			DrawBox(HEIGHT/2-1,WIDTH/2-5,1,10);
			move(HEIGHT/2,WIDTH/2-4);
			printw("Good-bye!!");
			refresh();
			getch();

			return;
		}
	}while(!gameOver);

	alarm(0);
	getch();
	DrawBox(HEIGHT/2-1,WIDTH/2-5,1,10);
	move(HEIGHT/2,WIDTH/2-4);
	printw("GameOver!!");
	refresh();
	getch();
	newRank(score);
}

char menu(){
	printw("1. play\n");
	printw("2. rank\n");
	printw("3. recommended play\n");
	printw("4. exit\n");
	return wgetch(stdscr);
}

/////////////////////////첫주차 실습에서 구현해야 할 함수/////////////////////////

int CheckToMove(char f[HEIGHT][WIDTH],int currentBlock,int blockRotate, int blockY, int blockX){
	// user code
	for(int i = 0; i < 4; i++) {
		for(int j = 0; j < 4; j++) {
			if(block[currentBlock][blockRotate][i][j]) {
				int y = i + blockY;
				int x = j + blockX;

				// 이동하고자 하는 좌표에 블록을 두었을 때 필드를 벗어나는 경우
				if(y >= HEIGHT || y < 0 || x < 0 || x >= WIDTH) return 0;
				// 블록을 놓으려는 필드에 이미 블록이 쌓여있는 경우
				if(f[y][x]) return 0;
			}
		}
	}
	return 1;

}

void DrawChange(char f[HEIGHT][WIDTH],int command,int currentBlock,int blockRotate, int blockY, int blockX){
	// user code

	//1. 이전 블록 정보를 찾는다. ProcessCommand의 switch문을 참조할 것
	//2. 이전 블록 정보를 지운다. DrawBlock함수 참조할 것.
	//3. 새로운 블록 정보를 그린다.
	int pX = blockX, pY = blockY, pR = blockRotate;
	switch(command) {
		case KEY_RIGHT:
			pX--;
			break;
		case KEY_LEFT:
			pX++;
			break;
		case KEY_DOWN:
			pY--;
			break;
		case KEY_UP:
			pR = (pR + 3) % 4;
			break;
		default:
			break;
	}

	// 현재 위치에서 내려갈 수 있는 가장 아래의 y좌표 찾음
	int preShadowY = pY + 1;
	while(preShadowY < HEIGHT) {
		if(CheckToMove(f, currentBlock, pR, preShadowY, pX)) preShadowY++;
		else break;
	}
	preShadowY--;

	for(int i = 0; i < 4; i++) {
		for(int j = 0; j < 4; j++) {
			if (block[currentBlock][pR][i][j]) {
				// 해당 좌표로 이동해서 블록 지움
				if(pY + i >= 0) { // 이전 블록을 지움
					move(pY + i + 1, pX + j + 1);
					char tile = '.';
					printw("%c", tile);
				}
				if(preShadowY + i >= 0) { // 이전 그림자 지움
					move(preShadowY + i + 1, pX + j + 1);
					char tile = '.';
					printw("%c", tile);
				}
			}
		}
	}
	//DrawBlock(blockY, blockX, currentBlock, blockRotate, ' ');
	DrawBlockWithFeatures(blockY, blockX, currentBlock, blockRotate);
	move(HEIGHT + 3, WIDTH + 3); // 커서를 필드 밖으로 이동
}

void BlockDown(int sig){
	// user code

	//강의자료 p26-27의 플로우차트를 참고한다.
	if (CheckToMove(field, nextBlock[0], blockRotate, blockY + 1, blockX)) {
		blockY++;
		DrawChange(field, KEY_DOWN, nextBlock[0], blockRotate, blockY, blockX);
	}
	else {
		if(blockY == -1) {
			gameOver = 1;
			return ;
		}
		
		//맞닿은 면적 및 삭제된 라인의 점수 계산
		score += AddBlockToField(field, nextBlock[0], blockRotate, blockY, blockX);
		score += DeleteLine(field);

		//next block 갱신
		for(int i = 0; i < BLOCK_NUM - 1; i++)
			nextBlock[i] = nextBlock[i + 1];
		nextBlock[BLOCK_NUM - 1] = rand() % 7;

		// init block
		blockRotate=0;
		blockY=-1;
		blockX=WIDTH/2-2;

		/* recommend */
		recRoot = InitRecTree();
		recommend(recRoot);

		DrawNextBlock(nextBlock);
		PrintScore(score);
		DrawField();
	}
	timed_out = 0;
}

int AddBlockToField(char f[HEIGHT][WIDTH],int currentBlock,int blockRotate, int blockY, int blockX){
	// user code

	//Block이 추가된 영역의 필드값을 바꾼다.
	int touched = 0; // 맞닿은 면적을 세는 변수
	for(int i = 0; i < 4; i++) {
		for(int j = 0; j < 4; j++) {
			if(block[currentBlock][blockRotate][i][j]) {
				int y = i + blockY;
				int x = j + blockX;

				if((0 <= y < HEIGHT) && (0 <= x < WIDTH)) {
					f[y][x] = 1;
					//바로 아래 필드의 요소가 1이거나, 바닥에 닿으면
					if(f[y + 1][x] || (y == HEIGHT - 1)) touched++;
				}
			}
		}
	}
	return touched * 10;
}

int DeleteLine(char f[HEIGHT][WIDTH]){
	// user code

	//1. 필드를 탐색하여, 꽉 찬 구간이 있는지 탐색한다.
	//2. 꽉 찬 구간이 있으면 해당 구간을 지운다. 즉, 해당 구간으로 필드값을 한칸씩 내린다.
	int fullLine = 0;
	int retScore, i, j;

	for(i = 0; i < HEIGHT; i++) {
		for(j = 0; j < WIDTH; j++) {
			if(!f[i][j]) { // 한 칸이라도 비어있으면 다음 줄 확인
				break;
			}
		}
		if(j == WIDTH) { // 한 줄이 꽉 차 있음
			fullLine++;
			for(int h = i; h > 0; h--) {
				for(int w = 0; w < WIDTH; w++) {
					f[h][w] = f[h - 1][w]; // 한 칸씩 아래로 내려서 꽉 찬 줄을 삭제
				}
			}
		}
	}
	
	retScore = fullLine * fullLine * 100;
	return retScore;
}

///////////////////////////////////////////////////////////////////////////

void DrawShadow(int y, int x, int blockID,int blockRotate){
	// user code
	// 더 이상 내려갈 수 없는 위치까지 y좌표를 아래로 내림
	int shadowY = y + 1;
	while(shadowY < HEIGHT) {
		if(CheckToMove(field, blockID, blockRotate, shadowY, x)) {
			shadowY++;
		}
		else break; // 아래로 이동할 수 없으면 이동 멈춤
	}
	shadowY--;
	DrawBlock(shadowY, x, blockID, blockRotate, '/'); // 그림자 그림
}

////////////////////////////////////// 2주차 실습 /////////////////////////////////////////////

LinkedList *createLinkedList() { // 연결리스트 초기화 함수
	LinkedList *ret = (LinkedList*) malloc(sizeof(LinkedList));
	ret->head = NULL;
	return ret;
}

void createRankList(){
	// 목적: Input파일인 "rank.txt"에서 랭킹 정보를 읽어들임, 읽어들인 정보로 랭킹 목록 생성
	// 1. "rank.txt"열기
	// 2. 파일에서 랭킹정보 읽어오기
	// 3. LinkedList로 저장
	// 4. 파일 닫기
	FILE *fp;
	int i, j;
	int rScore;
	char userName[NAMELEN];

	//1. 파일 열기
	fp = fopen("rank.txt", "r");
	if(!fp) {
		printw("File does not exist!\n");
	}
	else {
		// 2. 정보읽어오기
		/* int fscanf(FILE* stream, const char* format, ...);
		stream:데이터를 읽어올 스트림의 FILE 객체를 가리키는 파일포인터
		format: 형식지정자 등등
		변수의 주소: 포인터
		return: 성공할 경우, fscanf 함수는 읽어들인 데이터의 수를 리턴, 실패하면 EOF리턴 */
		// EOF(End Of File): 실제로 이 값은 -1을 나타냄, EOF가 나타날때까지 입력받아오는 if문

		// 연결리스트 생성
		rankList = createLinkedList();
		// 파일 읽기
		if (fscanf(fp, "%d", &rankCount) != EOF) {
			for(i = 0; i < rankCount; i++) {
				fscanf(fp, "%s %d\n", userName, &rScore);

				// 새로운 노드 생성
				Node *newNode = (Node*) malloc(sizeof(Node));
				newNode->score = rScore;
				strcpy(newNode->name, userName);
				newNode->prev = NULL;
				newNode->next = NULL;

				// 연결리스트에 삽입
				if(!rankList->head) { // 리스트가 비어있을 때
					rankList->head = newNode;
				}
				else { // 맨 끝에 삽입
					Node *cur = rankList->head;
					while(cur->next) {
						cur = cur->next;
					}
					newNode->prev = cur;
					cur->next = newNode;
				}	
			}
		}
		else {
			printw("File open error\n");
		}
	}
	// 4. 파일닫기
	fclose(fp);
}

void rank(){
	//목적: rank 메뉴를 출력하고 점수 순으로 X부터~Y까지 출력함
	//1. 문자열 초기화

	int X = -1, Y = -1, ch, i, j;
	int count = 0;
	clear();

	//2. printw()로 3개의 메뉴출력
	printw("1. list ranks from X to Y\n");
	printw("2. list ranks by a specific name\n");
	printw("3. delete a specific rank X\n");

	//3. wgetch()를 사용하여 변수 ch에 입력받은 메뉴번호 저장
	ch = wgetch(stdscr);

	//4. 각 메뉴에 따라 입력받을 값을 변수에 저장
	//4-1. 메뉴1: X, Y를 입력받고 적절한 input인지 확인 후(X<=Y), X와 Y사이의 rank 출력
	if (ch == '1') {
		echo();
		printw("X: ");
		scanw("%d", &X);
		printw("Y: ");
		scanw("%d", &Y);
		noecho();

		// X와 Y 범위 벗어날 경우
		if(X <= 0 || X > rankCount) X = 1;
		if(Y <= 0 || Y > rankCount) Y = rankCount;

		printw("     name      |     score     \n");
		printw("-------------------------------\n");

		if (X > Y || (!rankList->head)) { // 연결리스트가 비어있을 경우, X > Y
			printw("seach failure: no rank in the list\n");
		}
		else {
			Node* cur = rankList->head;
			
			// X 순위 노드 찾기 (1부터 시작)
			while(cur) {
				count++;
				if(count == X) break;
				cur = cur->next;
			}
			while(count <= Y && cur) { // 정보 출력 (X ~ Y)
				printw(" %-13s | %d\n", cur->name, cur->score);
				count++;
				cur = cur->next;
			}
		}
	}
	//4-2. 메뉴2: 문자열을 받아 저장된 이름과 비교하고 이름에 해당하는 리스트를 출력
	else if ( ch == '2') {
		char str[NAMELEN+1];
		int check = 0;

		// 이름 입력 받기
		echo();
		printw("input the name: ");
		getstr(str);
		noecho();

		printw("     name      |     score     \n");
		printw("-------------------------------\n");


		Node *cur = rankList->head;
		while(cur) {
			if(!strcmp(cur->name, str)) {
				printw(" %-13s | %d\n", cur->name, cur->score);
				check = 1;
			}
			cur = cur->next;
		}
		if(!check) printw("search failure: no name in the list\n");

	}

	//4-3. 메뉴3: rank번호를 입력받아 리스트에서 삭제
	else if ( ch == '3') {
		int num;
		int count = 0;

		echo();
		printw("input the rank: ");
		scanw("%d", &num);
		noecho();
		
		// 랭킹 범위에 맞지 않을 경우
		if(num <= 0 || num > rankCount)
			printw("\nsearch failure: the rank not in the list\n");
		else {
			Node *cur = rankList->head;

			// 순위 노드는 1부터 시작, 랭킹 찾기
			while(cur) {
				count++;
				if(count == num) break;
				cur = cur->next;
			}
			Node* delNode = cur;

			if(cur == rankList->head) { // 삭제하려는 노드가 연결리스트의 head 일 때
				rankList->head = cur->next;
				cur->next->prev = NULL;	
			}
			else if(cur->next){ // 중간 노드
				cur->prev->next = cur->next;
				cur->next->prev = cur->prev;
			}
			else { // 마지막 노드일 때
				cur->prev->next = NULL;
			}
			free(cur);
			rankCount--;
			printw("\nresult: the rank deleted\n");
		}
	}
	getch();
}

void writeRankFile(){
	// 목적: 추가된 랭킹 정보가 있으면 새로운 정보를 "rank.txt"에 쓰고 없으면 종료
	int sn, i;
	//1. "rank.txt" 연다

	FILE *fp = fopen("rank.txt", "w");
	if(!fp) {
		printw("File does not exist!\n");
	}
	else {
		//2. 랭킹 정보들의 수를 "rank.txt"에 기록
		fprintf(fp, "%d\n", rankCount);

		//3. 탐색할 노드가 더 있는지 체크하고 있으면 다음 노드로 이동, 없으면 종료
		//전역 변수인 rankList 안에 들어있는 점수 정보를 다시 처음부터 입력
		Node *cur = rankList->head;
		while(cur) {
			fprintf(fp, "%s %d\n", cur->name, cur->score);
			cur = cur->next;
		}
	}
	fclose(fp);
}

void newRank(int score){
	// 목적: GameOver시 호출되어 사용자 이름을 입력받고 score와 함께 리스트의 적절한 위치에 저장
	
	char str[NAMELEN+1];
	int i, j;
	clear();
	//1. 사용자 이름을 입력받음
	printw("your name: ");
	echo();
	scanw("%s", str);
	noecho();

	//2. 새로운 노드를 생성해 이름과 점수를 저장, score_number가
	Node *newNode = (Node *) malloc(sizeof(Node));
	newNode->score = score;
	newNode->next = NULL;
	newNode->prev = NULL;
	strcpy(newNode->name, str);
	
	if(!rankList->head) { // 연결리스트가 비어있으면
		rankList->head = newNode;
		rankCount++;
	}
	else {
		Node *cur = rankList->head;
		while(cur) { // score보다 작은 점수를 가진 노드를 찾으면 break
			if(cur->score >= score) {
				cur = cur->next;
			}
			else break;
		}
		newNode->next = cur;
		newNode->prev = cur->prev;
		cur->prev->next = newNode;
		cur->prev = newNode;
		rankCount++;
	}
	writeRankFile();
	
}

void DrawRecommend(int y, int x, int blockID,int blockRotate){
	// user code
	DrawBlock(y, x, blockID, blockRotate, 'R');
}

void swap(RecNode **a, RecNode **b) {
	RecNode *tmp = *a;
	*a = *b;
	*b = tmp;
}

// 선택 정렬 내림차순
void selectionSort(RecNode **arr, int size){
	int i, j, maxIdx;

	for(i = 0; i < size - 1; i++) {
		maxIdx = i;
		for(j = i + 1; j < size; j++) {
			if(arr[j]->accumulatedScore > arr[maxIdx]->accumulatedScore)
				maxIdx = j;
		}
		swap(&arr[maxIdx], &arr[i]);
	}
}

RecNode *makeNewNode(RecNode *root) {
	RecNode *newNode = (RecNode*) malloc(sizeof(RecNode));
	newNode->level = root->level + 1;
	newNode->accumulatedScore = root->accumulatedScore;
	memcpy(newNode->recField, root->recField, sizeof(root->recField));

	return newNode;
}

int recommend(RecNode *root){
	int max=-1; // 미리 보이는 블럭의 추천 배치까지 고려했을 때 얻을 수 있는 최대 점수
	int child_num=0;

	if(root->level == BLOCK_NUM) return 0;

	root->child = (RecNode**) malloc(sizeof(RecNode*)*CHILDREN_MAX);

	// user code
	// BFS로 score 계산해서 선택 정렬 후 10개의 자식 노드를 뽑아서 다시 진행
	// 1. select sort 제대로 되는지 확인하기
	// 2. RecNode에 r,x,y값 넣기
	// 3. max값이 갱신 될 때 level이 1이면 recommend값 갱신하기
	// 4. 이게 되면 nextbox(BLOCK_NUM)를 4,5..,6? 까지 늘려보기 (InitTetris, BlockDown)
	// 5. Block_Num도 맞춰서 증가
	for(int r = 0; r < NUM_OF_ROTATE; r++) {
		for(int x = -BLOCK_WIDTH; x <= WIDTH + BLOCK_WIDTH; x++) {
			// 맞닿을 면적까지 y 좌표 내리기
			int y = 0;
			while(y < HEIGHT) {
				if(CheckToMove(root->recField, nextBlock[root->level-1], r, y, x)) {
					y++;
				}
				else break; // 아래로 이동할 수 없으면 이동 멈춤
			}
			y--;
			if(y<0) continue;

			RecNode* newNode = makeNewNode(root); //root 정보의 노드를 자식 노드에 저장
			newNode->accumulatedScore += AddBlockToField(newNode->recField, nextBlock[root->level-1], r, y, x);
			newNode->accumulatedScore += DeleteLine(newNode->recField);

			// recommend info 기록
			newNode->r = r;
			newNode->x = x;
			newNode->y = y;
			root->child[child_num++] = newNode;
		}
	}

	selectionSort(root->child, child_num);
	for(int c = 0; c < child_num; c++) {
		if(c < MAX_BFS) {
			if(root->level < BLOCK_NUM) // 자식노드로 추천할 위치 계산하기
				root->child[c]->accumulatedScore += recommend(root->child[c]);

			if(root->child[c]->accumulatedScore > max) { // max 갱신
				max = root->child[c]->accumulatedScore;
				if(root->level == 1) { // 재귀 끝나고 올라오면서 루트이면 recommend block  배치 정보 갱신
					recommendR = root->child[c]->r;
					recommendX = root->child[c]->x;
					recommendY = root->child[c]->y;
				}
			}
		}
		//pruning branch
		free(root->child[c]);
	}

	free(root->child);

	return max;
}

void recommendedPlay(){
	// user code
}

/* 테트리스 1주차 과제 함수 */
void DrawBlockWithFeatures(int y, int x, int blockID, int blockRotate) {
	DrawRecommend(recommendY, recommendX, blockID, recommendR);
	DrawBlock(y, x, blockID, blockRotate, ' '); // 블록 그림
	DrawShadow(y, x, blockID, blockRotate); // 그림자 그림
}